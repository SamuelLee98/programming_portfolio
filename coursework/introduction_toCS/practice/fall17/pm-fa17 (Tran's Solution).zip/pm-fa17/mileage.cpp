#include <iostream>
#include <fstream>

#include "mlib.h"
using namespace std;


/**
 * main
 *
 * Description:  Overall application should read in mpg information from
 *               the file specified at the command line and then
 *               take pairs of integers representing speed (in mph) followed by
 *               the number of minutes driven at that speed.
 *               It should then output the number of gallons consumed by 
 *               each car type for the given journey and, finally, output
 *               the car type with the minimum fuel consumption.
 *          
 * Parameters:
 *    argc      Number of command line arguments
 *
 *    argv      array of pointers to character arrays which are the command
 *              line arguments
 * 
 * Returns:
 *   0 if normal execution complete
 *   1 if the command line argument is not provided or if the provided
 *     filename does not represent a valid file
 */
int main(int argc, char* argv[])
{
  //---------- YOU COMPLETE! --------------------
  // YOU CAN STILL GET A FEW POINTS OF CREDIT FOR
  // PARTIALLY WORKING CODE
  //---------------------------------------------
	if (argc < 2)
	{
		cout << "No filename error" << endl;
		return 1;
	}
	ifstream ifile(argv[1]);
	if (ifile.fail())
	{
		cout << "File open error" << endl;
		return 1;
	}

	int number_of_car_types;
	int** cars;
	cars = read_mpg(argv[1], &number_of_car_types);

	int speed;
	int time;
	int count = 0;

	do
	{
		cin >> speed >> time;
		count++;

		for (int i = 0; i < 4; i++)
		{
			convert_speed_time_to_gallons(speed, time, cars[i]);
		}

	}
	while (speed != -1 && speed != -1);


	// Deallocate 2D array used for the fuel consumption
	for (int i=0; i < number_of_car_types; i++)
	{
		delete[] cars[i];
	}
	delete[] cars; 
	return 0;
}
